/*
 * PID_Control_V2_Atmega328p.c
 *
 * Created: 8/03/2017 5:06:09 PM
 * Author: Jessica
 */ 

#include "PID Control V2 Atmega328p.h"

// ===================== PID Algorithm ==================== //

void pid_Initialise(void)
{
	pid_stored_data->roll_lastError = 0;
	pid_stored_data->roll_sumError = 0;
	pid_stored_data->pitch_lastError = 0;
	pid_stored_data->pitch_sumError = 0;
	pid_stored_data->yaw_lastError = 0;
	pid_stored_data->yaw_sumError = 0;
}


void pid_compute(	double &roll_in, double &roll_out,
					double &pitch_in,double &pitch_out,
					double &yaw_in, double &yaw_out)
{
	
	
}
