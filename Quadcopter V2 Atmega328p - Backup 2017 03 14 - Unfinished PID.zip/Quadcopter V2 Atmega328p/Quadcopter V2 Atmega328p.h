/*
 * Quadcopter_V2_Atmega328p.h
 *
 * Created: 4/03/2017 8:17:40 AM
 *  Author: Personal
 */ 


#ifndef QUADCOPTER V2 ATMEGA328P_H_
#define QUADCOPTER V2 ATMEGA328P_H_


// ================== PID Flight Control ================== //
#define SAFE

//-------PID Config----------
#define ROLL_PID_KP  0.250
#define ROLL_PID_KI  0.950
#define ROLL_PID_KD  0.011
#define ROLL_PID_MIN  -200.0
#define ROLL_PID_MAX  200.0

#define PITCH_PID_KP  0.250
#define PITCH_PID_KI  0.950
#define PITCH_PID_KD  0.011
#define PITCH_PID_MIN  -200.0
#define PITCH_PID_MAX  200.0

#define YAW_PID_KP  0.680
#define YAW_PID_KI  0.500
#define YAW_PID_KD  0.0001
#define YAW_PID_MIN  100.0
#define YAW_PID_MAX  100.0

//-------RX Config----------
#define THROTTLE_RMIN  1000
#define THROTTLE_SAFE_SHUTOFF 1120
#define THROTTLE_RMAX  1900
#define THROTTLE_RMID  1470

#define ROLL_RMIN  THROTTLE_RMIN
#define ROLL_RMAX  THROTTLE_RMAX
#define ROLL_WMIN  -30
#define ROLL_WMAX  30

#define PITCH_RMIN  THROTTLE_RMIN
#define PITCH_RMAX  THROTTLE_RMAX
#define PITCH_WMIN  -30
#define PITCH_WMAX  30

#define YAW_RMIN  THROTTLE_RMIN
#define YAW_RMAX  THROTTLE_RMAX
#define YAW_WMIN  -30
#define YAW_WMAX  30

//-------Motor PWM Levels
#define MOTOR_ZERO_LEVEL  1000
#define MOTOR_ARM_START  1500
#define MOTOR_MAX_LEVEL  2000

float angleX,angleY,angleZ; // Angles

int throttle; // RX Signals
volatile int rx_values[4]; // ROLL, PITCH, THROTTLE, YAW
#define RX_ROLL 0
#define RX_PITCH 1
#define RX_THROTTLE 2
#define RX_YAW 3
double pid_roll_in,   pid_roll_out,   pid_roll_setpoint; // PID variables
double pid_pitch_in,  pid_pitch_out,  pid_pitch_setpoint; // PID variables
double pid_yaw_in,    pid_yaw_out,    pid_yaw_setpoint; // PID variables
int m0, m1, m2, m3; // Front, Right, Back, Left motors
unsigned long prev_time; // Track loop time.

void flyPID_test(void);
void flyPID_initialise(void);
void flyPID_imu_update(void);
void flyPID_control_update(void);
void flyPID_setpoint_update(void);
void flyPID_pid_update(void);
void flyPID_pid_compute(void);
void flyPID_update_motors(int m0, int m1, int m2, int m3);



// ===================== PID Algorithm ==================== //
#define SCALING_FACTOR 128



#define MAX_ERROR		INT16_MAX
#define MAX_SUM_ERROR	INT32_MAX

// Maximum value of variables (avoid sign/overflow problem)
#define MAX_INT INT16_MAX
#define MAX_LONG INT32_MAX
#define MAX_I_TERM (MAX_LONG / 2)

// Boolean values
#define FALSE 0
#define TRUE 1

void pid_Init(int16_t p_factor, int16_t i_factor, int16_t d_factor, struct PID_DATA *pid);
int16_t pid_Controller(int16_t setPoint, int16_t processValue, struct PID_DATA *pid_st);
void pid_Reset_Integrator(pidData_t *pid_st);


#endif /* QUADCOPTER V2 ATMEGA328P_H_ */