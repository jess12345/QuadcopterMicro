/*
 * Quadcopter_V2_Atmega328p.c
 *
 * Created: 4/03/2017 8:08:30 AM
 *  Author: Personal
 */ 


#include "Quadcopter V2 Atmega328p.h"
#include "Peripherals V2 Atmega328p.h"
#include "PID Control V2 Atmega328p.h"

int main(void)
{
	gpio_initialize(); // Initialize GPIO pins
	printf("Jess's Quadcopter\n\r"); //Intro sentence
	led_startUpSequence(); // LED startup indicator
	
	//twi_test();
	//ADXL345_test();
	//ITG3200_test();
	//HMC5883L_test();
	//GP2Y0A21_test();
	flyPID_test();
}



// ================== PID Flight Control ================== //

void flyPID_test(void)
{
	flyPID_initialise();
	
	while(1)
	{
		flyPID_imu_update();
		flyPID_control_update();
		_delay_ms(100); // Loop approximately every 100ms.
		// *** Will replace with a timed loop using interrupts later.
	}
}


void flyPID_initialise(void)
{
	// Angles
	angleX = 0.0;
	angleY = 0.0;
	angleZ = 0.0;

	// RX Signals
	throttle=THROTTLE_RMIN;
	rx_values[RX_ROLL] = 0;
	rx_values[RX_PITCH] = 0;
	rx_values[RX_THROTTLE] = 0;
	rx_values[RX_YAW] = 0;

	// PID variables
	pid_roll_in = 0;
	pid_roll_out = 0;
	pid_roll_setpoint = 0;
	pid_pitch_in = 0;
	pid_pitch_out = 0;
	pid_pitch_setpoint = 0;
	pid_yaw_in = 0;
	pid_yaw_out = 0;
	pid_yaw_setpoint = 0;
	
	// Motors
	m0 = 0; // front
	m1 = 0; // right
	m2 = 0; // back
	m3 = 0; // left

	// Track loop time.
	prev_time = 0;
	
	
	
}

void flyPID_imu_update(void)
{
	
	
	
}

void flyPID_control_update(void)
{
	throttle = flyPID_linear_map(rx_values[RX_THROTTLE],THROTTLE_RMIN,THROTTLE_RMAX,MOTOR_ZERO_LEVEL,MOTOR_MAX_LEVEL);
	  
	flyPID_setpoint_update();
	flyPID_pid_update();
	flyPID_pid_compute();
	  
	// yaw control disabled for stabilization testing...
	m0 = throttle + pid_pitch_out ;//+ pid_yaw_out;
	m1 = throttle + pid_roll_out ;//- pid_yaw_out;
	m2 = throttle - pid_pitch_out ;//+ pid_yaw_out;
	m3 = throttle - pid_roll_out ;//- pid_yaw_out;
	  
	#ifdef SAFE
	if(throttle < THROTTLE_SAFE_SHUTOFF)
	{
		m0 = m1 = m2 = m3 = MOTOR_ZERO_LEVEL;
	}
	#endif
	  
	flyPID_update_motors(m0, m1, m2, m3);
}

int flyPID_linear_map(int input_value, int input_low, int input_high, int output_low, int output_high)
{
	return (output_low + (output_high - output_low) * (input_value - input_low) / (input_high - input_low));
}

void flyPID_setpoint_update(void)
{
	// here we allow +- 20 for noise and sensitivity on the RX controls...
	
	// ROLL rx at mid level?
	if(rx_values[0] > THROTTLE_RMID - 20 && rx_values[0] < THROTTLE_RMID + 20){
		pid_roll_setpoint = 0;
	}else{
		pid_roll_setpoint = map(rx_values[0],ROLL_RMIN,ROLL_RMAX,ROLL_WMIN,ROLL_WMAX);
	}
	
	//PITCH rx at mid level?
	if(rx_values[1] > THROTTLE_RMID - 20 && rx_values[1] < THROTTLE_RMID + 20){
		pid_pitch_setpoint = 0;
	}else{
		pid_pitch_setpoint = map(rx_values[1],PITCH_RMIN,PITCH_RMAX,PITCH_WMIN,PITCH_WMAX);
	}
	
	//YAW rx at mid level?
	if(rx_values[3] > THROTTLE_RMID - 20 && rx_values[3] < THROTTLE_RMID + 20){
		pid_yaw_setpoint = 0;
	}else{
		pid_yaw_setpoint = map(rx_values[3],YAW_RMIN,YAW_RMAX,YAW_WMIN,YAW_WMAX);
	}
}

void flyPID_pid_update(void)
{
	pid_roll_in = angleX;
	pid_pitch_in = angleY;
	pid_yaw_in = angleZ;
}

void flyPID_pid_compute(void)
{
	roll_controller.Compute();
	pitch_controller.Compute();
	yaw_controller.Compute();
	
	pid_yaw_out = 
	
}

void flyPID_update_motors(int m0, int m1, int m2, int m3)
{
	
	
	
}

// ===================== PID Algorithm ==================== //

